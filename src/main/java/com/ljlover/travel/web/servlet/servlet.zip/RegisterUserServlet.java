package com.ljlover.travel.web.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ljlover.travel.domain.ResultInfo;
import com.ljlover.travel.domain.User;
import com.ljlover.travel.service.UserService;
import com.ljlover.travel.service.impl.UserServiceImpl;
import com.ljlover.travel.util.BeanUtil;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;

/**
 * @Program: travel
 * @Description: 处理登录页面servlet
 * @Author: ljlover
 * @Date: 2019/8/8 7:33
 * All rights reserved.
 */

@WebServlet("/registerUserServlet")
public class RegisterUserServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ResultInfo resultInfo = null;

        // 验证码校验
        HttpSession session = request.getSession();
        String checkCodeServer = (String) session.getAttribute("CHECK_CODE_SERVER");
        session.removeAttribute("CHECK_CODE_SERVER");

        String check = request.getParameter("check");

        if (checkCodeServer == null || !checkCodeServer.equalsIgnoreCase(check)) {
            resultInfo = new ResultInfo(false, "验证码错误");
            responseJson(response, resultInfo);
            return;
        }
        // 获得数据
        Map<String, String[]> map = request.getParameterMap();

        // 封装数据到user
        User user = BeanUtil.populate(map);
        // 注册用户
        UserService userService = new UserServiceImpl();

        // 获得注册结果信息
        boolean flag = userService.regist(user);

        if (flag) {
            resultInfo = new ResultInfo(true);
        } else {
            resultInfo = new ResultInfo(false, "注册失败！");
        }
        responseJson(response, resultInfo);


    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    private void responseJson(HttpServletResponse response, ResultInfo resultInfo) throws IOException {

        // 序列化结果信息
        ObjectMapper mapper = new ObjectMapper();

        String resultInfoJson = mapper.writeValueAsString(resultInfo);

        // 返回数据到客户端
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write(resultInfoJson);
    }
}
