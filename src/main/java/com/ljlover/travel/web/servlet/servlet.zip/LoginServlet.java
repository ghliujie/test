package com.ljlover.travel.web.servlet;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ljlover.travel.domain.ResultInfo;
import com.ljlover.travel.domain.User;
import com.ljlover.travel.service.UserService;
import com.ljlover.travel.service.impl.UserServiceImpl;
import com.ljlover.travel.util.BeanUtil;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * @Program LoginServlet
 * @Description:
 * @Author: ljlover
 * @Date: 2019/8/8 10:56
 * All rights reserved.
 */

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {

    private static final String N = "N";
    private static final String Y = "Y";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Map<String, String[]> map = request.getParameterMap();

        User user = BeanUtil.populate(map);

        UserService userService = new UserServiceImpl();
        System.out.println("testuser:"+user);

        User loginUser = userService.login(user);

        ResultInfo resultInfo = null;

        System.out.println("loginUser:" + loginUser);

        if (loginUser == null) {
            resultInfo = new ResultInfo(false, "账号或者密码错误");

        }

        if (loginUser != null && N.equals(loginUser.getStatus())) {
            resultInfo = new ResultInfo(false, "账号未激活，请登录邮箱激活");

        }

        if (loginUser != null && Y.equals(loginUser.getStatus())) {
            resultInfo = new ResultInfo(true);
            request.getSession().setAttribute("user",loginUser);
        }


        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), resultInfo);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
